# I love your curiosity

*The best in business have boundless curiosity and open minds.*